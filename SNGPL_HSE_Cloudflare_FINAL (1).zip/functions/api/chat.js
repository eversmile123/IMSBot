export async function onRequestPost(context) {
  const { request, env } = context;
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };
  try {
    if (!env.ANTHROPIC_API_KEY) {
      return new Response(JSON.stringify({
        error: { message: 'ANTHROPIC_API_KEY not set. Add it in Cloudflare Pages → Settings → Environment Variables. Or use Ollama/Groq mode via the ⚙️ button.' }
      }), { status: 500, headers: cors });
    }
    const body = await request.json();
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    return new Response(JSON.stringify(data), { status: response.status, headers: cors });
  } catch (err) {
    return new Response(JSON.stringify({ error: { message: 'Worker error: ' + err.message } }), { status: 500, headers: cors });
  }
}
export async function onRequestOptions() {
  return new Response(null, { headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }});
}
